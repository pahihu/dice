#ifndef  CLIB_INPUT_PROTOS_H
#define  CLIB_INPUT_PROTOS_H
/*
**	$VER: input_protos.h 36.2 (07.11.90)
**	Includes Release 39.108
**
**	C prototypes. For use with 32 bit integers only.
**
**	(C) Copyright 1990-1992 Commodore-Amiga, Inc.
**	    All Rights Reserved
*/
#ifndef  EXEC_TYPES_H
#include <exec/types.h>
#endif
/*--- functions in V36 or higher (distributed as Release 2.0) ---*/
UWORD PeekQualifier( void );
#endif	 /* CLIB_INPUT_PROTOS_H */
