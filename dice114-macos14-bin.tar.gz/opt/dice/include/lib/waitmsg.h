
/*
 * $VER: lib/waitmsg.h 1.0 (17.4.93)
 *
 * (c)Copyright 1992 Obvious Implementations Corp, All Rights Reserved
 */

#ifndef LIB_WAITMSG_H
#define LIB_WAITMSG_H

extern void WaitMsg(struct Message *);

#endif

