
/*
 * $VER: lib/muldiv.h 1.0 (17.4.93)
 *
 * (c)Copyright 1992 Obvious Implementations Corp, All Rights Reserved
 */

extern __stkargs long MulDiv(long, long, long);
extern __stkargs unsigned long MulDivU(unsigned long, unsigned long, unsigned long);

