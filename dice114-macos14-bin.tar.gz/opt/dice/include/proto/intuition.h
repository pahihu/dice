/* $VER: proto/intuition.h 1.0 (17.4.93) */
#ifndef INTUITION_PROTO_H
#define INTUITION_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/intuition_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct IntuitionBase *IntuitionBase;
#include <pragmas/intuition_pragmas.h>
#endif
#endif
