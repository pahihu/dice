/* $VER: proto/iffparse.h 1.0 (17.4.93) */
#ifndef IFFPARSE_PROTO_H
#define IFFPARSE_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/iffparse_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *IFFParseBase;
#include <pragmas/iffparse_pragmas.h>
#endif
#endif
