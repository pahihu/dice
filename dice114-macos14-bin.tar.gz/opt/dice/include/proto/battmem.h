/* $VER: proto/battmem.h 1.0 (17.4.93) */
#ifndef BATTMEM_PROTO_H
#define BATTMEM_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/battmem_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *BattMemBase;
#include <pragmas/battmem_pragmas.h>
#endif
#endif
