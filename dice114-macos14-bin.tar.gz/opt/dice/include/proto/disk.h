/* $VER: proto/disk.h 1.0 (17.4.93) */
#ifndef DISK_PROTO_H
#define DISK_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/disk_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *DiskBase;
#include <pragmas/disk_pragmas.h>
#endif
#endif
