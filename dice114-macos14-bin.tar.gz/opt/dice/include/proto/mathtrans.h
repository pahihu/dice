/* $VER: proto/mathtrans.h 1.0 (17.4.93) */
#ifndef MATHTRANS_PROTO_H
#define MATHTRANS_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/mathtrans_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *MathTransBase;
#include <pragmas/mathtrans_pragmas.h>
#endif
#endif
