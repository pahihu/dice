/* $VER: proto/amigaguide.h 1.0 (17.4.93) */
#ifndef AMIGAGUIDE_PROTO_H
#define AMIGAGUIDE_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/amigaguide_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *AmigaGuideBase;
#include <pragmas/amigaguide_pragmas.h>
#endif
#endif
