/* $VER: proto/icon.h 1.0 (17.4.93) */
#ifndef ICON_PROTO_H
#define ICON_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/icon_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *IconBase;
#include <pragmas/icon_pragmas.h>
#endif
#endif
