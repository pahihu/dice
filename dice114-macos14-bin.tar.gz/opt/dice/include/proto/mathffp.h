/* $VER: proto/mathffp.h 1.0 (17.4.93) */
#ifndef MATHFFP_PROTO_H
#define MATHFFP_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/mathffp_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *MathBase;
#include <pragmas/mathffp_pragmas.h>
#endif
#endif
