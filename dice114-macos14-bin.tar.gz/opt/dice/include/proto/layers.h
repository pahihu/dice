/* $VER: proto/layers.h 1.0 (17.4.93) */
#ifndef LAYERS_PROTO_H
#define LAYERS_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/layers_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct LayersBase *LayersBase;
#include <pragmas/layers_pragmas.h>
#endif
#endif
