/* $VER: proto/locale.h 1.0 (17.4.93) */
#ifndef LOCALE_PROTO_H
#define LOCALE_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/locale_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
#include <pragmas/locale_pragmas.h>
#endif
#endif
