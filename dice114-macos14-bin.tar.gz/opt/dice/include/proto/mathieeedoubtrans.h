/* $VER: proto/mathieeedoubtrans.h 1.0 (17.4.93) */
#ifndef MATHIEEEDOUBTRANS_PROTO_H
#define MATHIEEEDOUBTRANS_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/mathieeedoubtrans_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *MathIeeeDoubTransBase;
#include <pragmas/mathieeedoubtrans_pragmas.h>
#endif
#endif
