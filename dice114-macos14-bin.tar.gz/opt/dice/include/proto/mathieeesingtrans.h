/* $VER: proto/mathieeesingtrans.h 1.0 (17.4.93) */
#ifndef MATHIEEESINGTRANS_PROTO_H
#define MATHIEEESINGTRANS_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/mathieeesingtrans_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *MathIeeeSingTransBase;
#include <pragmas/mathieeesingtrans_pragmas.h>
#endif
#endif
