/* $VER: proto/expansion.h 1.0 (17.4.93) */
#ifndef EXPANSION_PROTO_H
#define EXPANSION_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/expansion_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *ExpansionBase;
#include <pragmas/expansion_pragmas.h>
#endif
#endif
