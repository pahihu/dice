/* $VER: proto/bullet.h 1.0 (17.4.93) */
#ifndef BULLET_PROTO_H
#define BULLET_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/bullet_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *BulletBase;
#include <pragmas/bullet_pragmas.h>
#endif
#endif
