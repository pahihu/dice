/* $VER: proto/commodities.h 1.0 (17.4.93) */
#ifndef COMMODITIES_PROTO_H
#define COMMODITIES_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/commodities_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *CxBase;
#include <pragmas/commodities_pragmas.h>
#endif
#endif
