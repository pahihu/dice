/* $VER: proto/rexxsyslib.h 1.0 (17.4.93) */
#ifndef REXXSYSLIB_PROTO_H
#define REXXSYSLIB_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/rexxsyslib_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *RexxSysBase;
#include <pragmas/rexxsyslib_pragmas.h>
#endif
#endif
