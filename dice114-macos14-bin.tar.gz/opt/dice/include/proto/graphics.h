/* $VER: proto/graphics.h 1.0 (17.4.93) */
#ifndef GRAPHICS_PROTO_H
#define GRAPHICS_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/graphics_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct GfxBase *GfxBase;
#include <pragmas/graphics_pragmas.h>
#endif
#endif
