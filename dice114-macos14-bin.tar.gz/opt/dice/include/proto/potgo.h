/* $VER: proto/potgo.h 1.0 (17.4.93) */
#ifndef POTGO_PROTO_H
#define POTGO_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/potgo_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *PotgoBase;
#include <pragmas/potgo_pragmas.h>
#endif
#endif
