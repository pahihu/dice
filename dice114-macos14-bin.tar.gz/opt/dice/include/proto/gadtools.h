/* $VER: proto/gadtools.h 1.0 (17.4.93) */
#ifndef GADTOOLS_PROTO_H
#define GADTOOLS_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/gadtools_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *GadToolsBase;
#include <pragmas/gadtools_pragmas.h>
#endif
#endif
