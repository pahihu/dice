/* $VER: proto/input.h 1.0 (17.4.93) */
#ifndef INPUT_PROTO_H
#define INPUT_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/input_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *InputBase;
#include <pragmas/input_pragmas.h>
#endif
#endif
