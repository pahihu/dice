/* $VER: proto/diskfont.h 1.0 (17.4.93) */
#ifndef DISKFONT_PROTO_H
#define DISKFONT_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/diskfont_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *DiskfontBase;
#include <pragmas/diskfont_pragmas.h>
#endif
#endif
