/* $VER: proto/ramdrive.h 1.0 (17.4.93) */
#ifndef RAMDRIVE_PROTO_H
#define RAMDRIVE_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/ramdrive_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *RamdriveDevice;
#include <pragmas/ramdrive_pragmas.h>
#endif
#endif
