/* $VER: proto/asl.h 1.0 (17.4.93) */
#ifndef ASL_PROTO_H
#define ASL_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/asl_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *AslBase;
#include <pragmas/asl_pragmas.h>
#endif
#endif
