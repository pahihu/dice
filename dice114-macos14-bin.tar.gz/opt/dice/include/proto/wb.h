/* $VER: proto/wb.h 1.0 (17.4.93) */
#ifndef WB_PROTO_H
#define WB_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/wb_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *WorkbenchBase;
#include <pragmas/wb_pragmas.h>
#endif
#endif
