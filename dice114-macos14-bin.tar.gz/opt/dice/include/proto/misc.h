/* $VER: proto/misc.h 1.0 (17.4.93) */
#ifndef MISC_PROTO_H
#define MISC_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/misc_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *MiscBase;
#include <pragmas/misc_pragmas.h>
#endif
#endif
