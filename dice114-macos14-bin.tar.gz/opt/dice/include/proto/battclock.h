/* $VER: proto/battclock.h 1.0 (17.4.93) */
#ifndef BATTCLOCK_PROTO_H
#define BATTCLOCK_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/battclock_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *BattClockBase;
#include <pragmas/battclock_pragmas.h>
#endif
#endif
