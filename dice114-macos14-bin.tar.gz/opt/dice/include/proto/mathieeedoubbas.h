/* $VER: proto/mathieeedoubbas.h 1.0 (17.4.93) */
#ifndef MATHIEEEDOUBBAS_PROTO_H
#define MATHIEEEDOUBBAS_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/mathieeedoubbas_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *MathIeeeDoubBasBase;
#include <pragmas/mathieeedoubbas_pragmas.h>
#endif
#endif
