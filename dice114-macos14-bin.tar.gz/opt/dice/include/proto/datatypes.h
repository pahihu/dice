/* $VER: proto/datatypes.h 1.0 (17.4.93) */
#ifndef DATATYPES_PROTO_H
#define DATATYPES_PROTO_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/datatypes_protos.h>
#ifdef __SUPPORTS_PRAGMAS__
extern struct Library *DataTypesBase;
#include <pragmas/datatypes_pragmas.h>
#endif
#endif
