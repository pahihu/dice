
/*
 * $VER: sys/param.h 1.0 (17.4.93)
 *
 * (c)Copyright 1992 Obvious Implementations Corp, All Rights Reserved
 */

#ifndef SYS_PARAM_H
#define SYS_PARAM_H

#include <sys/types.h>
#define MAXPATHLEN  512
#define MACHINE "amiga"

#endif
