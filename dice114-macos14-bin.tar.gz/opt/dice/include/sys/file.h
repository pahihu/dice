
/*
 * $VER: sys/file.h 1.0 (17.4.93)
 *
 * (c)Copyright 1992 Obvious Implementations Corp, All Rights Reserved
 */

#ifndef FCNTL_H
#include <fcntl.h>
#endif
