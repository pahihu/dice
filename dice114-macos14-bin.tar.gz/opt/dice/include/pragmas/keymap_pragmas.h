/* $VER: ../include/pragmas/keymap_pragmas.h 1.0 (9.8.97) */
#ifndef KeymapBase_PRAGMA_H
#define KeymapBase_PRAGMA_H

#pragma libcall KeymapBase SetKeyMapDefault 1e 801
#pragma libcall KeymapBase AskKeyMapDefault 24 00
#pragma libcall KeymapBase MapRawKey 2a a19804
#pragma libcall KeymapBase MapANSI 30 a190805

#endif
