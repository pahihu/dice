/* $VER: ../include/pragmas/wb_pragmas.h 1.0 (9.8.97) */
#ifndef WorkbenchBase_PRAGMA_H
#define WorkbenchBase_PRAGMA_H

#pragma libcall WorkbenchBase AddAppWindowA 30 a981005
#pragma libcall WorkbenchBase RemoveAppWindow 36 801
#pragma libcall WorkbenchBase AddAppIconA 3c cba981007
#pragma libcall WorkbenchBase RemoveAppIcon 42 801
#pragma libcall WorkbenchBase AddAppMenuItemA 48 a981005
#pragma libcall WorkbenchBase RemoveAppMenuItem 4e 801
#pragma libcall WorkbenchBase WBInfo 5a a9803

#endif
