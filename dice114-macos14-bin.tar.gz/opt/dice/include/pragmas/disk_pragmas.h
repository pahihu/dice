/* $VER: ../include/pragmas/disk_pragmas.h 1.0 (9.8.97) */
#ifndef DiskBase_PRAGMA_H
#define DiskBase_PRAGMA_H

#pragma libcall DiskBase AllocUnit 6 001
#pragma libcall DiskBase FreeUnit c 001
#pragma libcall DiskBase GetUnit 12 901
#pragma libcall DiskBase GiveUnit 18 00
#pragma libcall DiskBase GetUnitID 1e 001
#pragma libcall DiskBase ReadUnitID 24 001

#endif
