/* $VER: ../include/pragmas/misc_pragmas.h 1.0 (9.8.97) */
#ifndef MiscBase_PRAGMA_H
#define MiscBase_PRAGMA_H

#pragma libcall MiscBase AllocMiscResource 6 9002
#pragma libcall MiscBase FreeMiscResource c 001

#endif
