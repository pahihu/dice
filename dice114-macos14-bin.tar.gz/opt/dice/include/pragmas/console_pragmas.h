/* $VER: ../include/pragmas/console_pragmas.h 1.0 (9.8.97) */
#ifndef ConsoleDevice_PRAGMA_H
#define ConsoleDevice_PRAGMA_H

#pragma libcall ConsoleDevice CDInputHandler 2a 9802
#pragma libcall ConsoleDevice RawKeyConvert 30 a19804

#endif
