/* $VER: ../include/pragmas/ramdrive_pragmas.h 1.0 (9.8.97) */
#ifndef RamdriveDevice_PRAGMA_H
#define RamdriveDevice_PRAGMA_H

#pragma libcall RamdriveDevice KillRAD0 2a 00
#pragma libcall RamdriveDevice KillRAD 30 001

#endif
