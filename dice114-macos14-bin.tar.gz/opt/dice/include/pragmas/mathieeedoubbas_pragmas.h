/* $VER: ../include/pragmas/mathieeedoubbas_pragmas.h 1.0 (9.8.97) */
#ifndef MathIeeeDoubBasBase_PRAGMA_H
#define MathIeeeDoubBasBase_PRAGMA_H

#pragma libcall MathIeeeDoubBasBase IEEEDPFix 1e 1002
#pragma libcall MathIeeeDoubBasBase IEEEDPFlt 24 001
#pragma libcall MathIeeeDoubBasBase IEEEDPCmp 2a 321004
#pragma libcall MathIeeeDoubBasBase IEEEDPTst 30 1002
#pragma libcall MathIeeeDoubBasBase IEEEDPAbs 36 1002
#pragma libcall MathIeeeDoubBasBase IEEEDPNeg 3c 1002
#pragma libcall MathIeeeDoubBasBase IEEEDPAdd 42 321004
#pragma libcall MathIeeeDoubBasBase IEEEDPSub 48 321004
#pragma libcall MathIeeeDoubBasBase IEEEDPMul 4e 321004
#pragma libcall MathIeeeDoubBasBase IEEEDPDiv 54 321004
#pragma libcall MathIeeeDoubBasBase IEEEDPFloor 5a 1002
#pragma libcall MathIeeeDoubBasBase IEEEDPCeil 60 1002

#endif
