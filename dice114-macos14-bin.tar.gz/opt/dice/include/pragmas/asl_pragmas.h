/* $VER: ../include/pragmas/asl_pragmas.h 1.0 (9.8.97) */
#ifndef AslBase_PRAGMA_H
#define AslBase_PRAGMA_H

#pragma libcall AslBase AllocFileRequest 1e 00
#pragma libcall AslBase FreeFileRequest 24 801
#pragma libcall AslBase RequestFile 2a 801
#pragma libcall AslBase AllocAslRequest 30 8002
#pragma libcall AslBase FreeAslRequest 36 801
#pragma libcall AslBase AslRequest 3c 9802

#endif
