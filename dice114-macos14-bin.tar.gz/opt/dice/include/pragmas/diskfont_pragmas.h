/* $VER: ../include/pragmas/diskfont_pragmas.h 1.0 (9.8.97) */
#ifndef DiskfontBase_PRAGMA_H
#define DiskfontBase_PRAGMA_H

#pragma libcall DiskfontBase OpenDiskFont 1e 801
#pragma libcall DiskfontBase AvailFonts 24 10803
#pragma libcall DiskfontBase NewFontContents 2a 9802
#pragma libcall DiskfontBase DisposeFontContents 30 901
#pragma libcall DiskfontBase NewScaledDiskFont 36 9802

#endif
