/* $VER: ../include/pragmas/cia_pragmas.h 1.0 (9.8.97) */
#ifndef UnknownBase_PRAGMA_H
#define UnknownBase_PRAGMA_H

#pragma libcall UnknownBase AddICRVector 6 90e03
#pragma libcall UnknownBase RemICRVector c 90e03
#pragma libcall UnknownBase AbleICR 12 0e02
#pragma libcall UnknownBase SetICR 18 0e02

#endif
