/* $VER: ../include/pragmas/input_pragmas.h 1.0 (9.8.97) */
#ifndef InputBase_PRAGMA_H
#define InputBase_PRAGMA_H

#pragma libcall InputBase PeekQualifier 2a 00

#endif
