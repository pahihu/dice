/* $VER: ../include/pragmas/potgo_pragmas.h 1.0 (9.8.97) */
#ifndef PotgoBase_PRAGMA_H
#define PotgoBase_PRAGMA_H

#pragma libcall PotgoBase AllocPotBits 6 001
#pragma libcall PotgoBase FreePotBits c 001
#pragma libcall PotgoBase WritePotgo 12 1002

#endif
