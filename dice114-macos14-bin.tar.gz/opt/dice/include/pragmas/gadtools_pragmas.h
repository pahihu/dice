/* $VER: ../include/pragmas/gadtools_pragmas.h 1.0 (9.8.97) */
#ifndef GadToolsBase_PRAGMA_H
#define GadToolsBase_PRAGMA_H

#pragma libcall GadToolsBase CreateGadgetA 1e a98004
#pragma libcall GadToolsBase FreeGadgets 24 801
#pragma libcall GadToolsBase GT_SetGadgetAttrsA 2a ba9804
#pragma libcall GadToolsBase CreateMenusA 30 9802
#pragma libcall GadToolsBase FreeMenus 36 801
#pragma libcall GadToolsBase LayoutMenuItemsA 3c a9803
#pragma libcall GadToolsBase LayoutMenusA 42 a9803
#pragma libcall GadToolsBase GT_GetIMsg 48 801
#pragma libcall GadToolsBase GT_ReplyIMsg 4e 901
#pragma libcall GadToolsBase GT_RefreshWindow 54 9802
#pragma libcall GadToolsBase GT_BeginRefresh 5a 801
#pragma libcall GadToolsBase GT_EndRefresh 60 0802
#pragma libcall GadToolsBase GT_FilterIMsg 66 901
#pragma libcall GadToolsBase GT_PostFilterIMsg 6c 901
#pragma libcall GadToolsBase CreateContext 72 801
#pragma libcall GadToolsBase DrawBevelBoxA 78 93210806
#pragma libcall GadToolsBase GetVisualInfoA 7e 9802
#pragma libcall GadToolsBase FreeVisualInfo 84 801
#pragma libcall GadToolsBase GT_GetGadgetAttrsA ae ba9804

#endif
