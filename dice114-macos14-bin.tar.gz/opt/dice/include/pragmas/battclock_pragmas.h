/* $VER: ../include/pragmas/battclock_pragmas.h 1.0 (9.8.97) */
#ifndef BattClockBase_PRAGMA_H
#define BattClockBase_PRAGMA_H

#pragma libcall BattClockBase ResetBattClock 6 00
#pragma libcall BattClockBase ReadBattClock c 00
#pragma libcall BattClockBase WriteBattClock 12 001

#endif
