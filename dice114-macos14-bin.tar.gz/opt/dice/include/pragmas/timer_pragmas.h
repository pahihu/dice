/* $VER: ../include/pragmas/timer_pragmas.h 1.0 (9.8.97) */
#ifndef TimerBase_PRAGMA_H
#define TimerBase_PRAGMA_H

#pragma libcall TimerBase AddTime 2a 9802
#pragma libcall TimerBase SubTime 30 9802
#pragma libcall TimerBase CmpTime 36 9802
#pragma libcall TimerBase ReadEClock 3c 801
#pragma libcall TimerBase GetSysTime 42 801

#endif
