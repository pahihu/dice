/* $VER: clib/misc_protos.h 1.0 (23.1.94) */
#ifndef MISC_PROTOS_H
#define MISC_PROTOS_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/misc_protos.h>  /* Note this is in the Amiga directory */
#if __SUPPORTS_PRAGMAS__
#ifdef __DICE_INLINE
extern struct Library *MiscBase;
#include <pragmas/misc_pragmas.h>
#endif
#endif
#endif
