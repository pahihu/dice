/* $VER: clib/mathieeesingtrans_protos.h 1.0 (23.1.94) */
#ifndef MATHIEEESINGTRANS_PROTOS_H
#define MATHIEEESINGTRANS_PROTOS_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/mathieeesingtrans_protos.h>  /* Note this is in the Amiga directory */
#if __SUPPORTS_PRAGMAS__
#ifdef __DICE_INLINE
extern struct Library *MathIeeeSingTransBase;
#include <pragmas/mathieeesingtrans_pragmas.h>
#endif
#endif
#endif
