/* $VER: clib/alib_protos.h 1.0 (17.4.93) */
#ifndef ALIB_PROTOS_H
#define ALIB_PROTOS_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/alib_protos.h>
#endif
