/* $VER: clib/wb_protos.h 1.0 (23.1.94) */
#ifndef WB_PROTOS_H
#define WB_PROTOS_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/wb_protos.h>  /* Note this is in the Amiga directory */
#if __SUPPORTS_PRAGMAS__
#ifdef __DICE_INLINE
extern struct Library *WorkbenchBase;
#include <pragmas/wb_pragmas.h>
#endif
#endif
#endif
