/* $VER: clib/mathffp_protos.h 1.0 (23.1.94) */
#ifndef MATHFFP_PROTOS_H
#define MATHFFP_PROTOS_H 1
#include <pragmas/config.h>
#include <exec/types.h>
#include <clib/mathffp_protos.h>  /* Note this is in the Amiga directory */
#if __SUPPORTS_PRAGMAS__
#ifdef __DICE_INLINE
extern struct Library *MathBase;
#include <pragmas/mathffp_pragmas.h>
#endif
#endif
#endif
